import { world } from "@minecraft/server";

const AUTHOR = "VigeNerSl";
const REG_SIZE = 32;
const PREFIX = "proc_r_";
const BITS = REG_SIZE * REG_SIZE;
const BYTES = Math.ceil(BITS / 8);

const cache = new Map();

function toHex(bytes) {
	let s = "";
	for (let i = 0; i < bytes.length; i++) {
		let h = bytes[i].toString(16);
		if (h.length === 1) h = "0" + h;
		s += h;
	}
	return s;
}

function fromHex(hex) {
	if (!hex || hex.length === 0) return new Uint8Array(0);
	const len = Math.floor(hex.length / 2);
	const out = new Uint8Array(len);
	for (let i = 0; i < len; i++) {
		out[i] = parseInt(hex.substr(i * 2, 2), 16);
	}
	return out;
}

function regKey(dimId, rx, rz) {
	return `${PREFIX}${dimId}_${rx}_${rz}`;
}

function getRegCoords(cx) {
	const rx = Math.floor(cx / REG_SIZE);
	const lx = cx - rx * REG_SIZE;
	return { rx, lx };
}

function getIdx(localX, localZ) {
	return localZ * REG_SIZE + localX;
}

function loadReg(dimId, rx, rz) {
	const key = regKey(dimId, rx, rz);
	let entry = cache.get(key);
	if (entry) return entry;

	const raw = world.getDynamicProperty(key);
	let bytes;
	if (typeof raw === "string" && raw.length > 0) {
		bytes = fromHex(raw);
		if (bytes.length < BYTES) {
			const full = new Uint8Array(BYTES);
			full.set(bytes);
			bytes = full;
		}
	} else {
		bytes = new Uint8Array(BYTES);
	}

	entry = { bytes, dirty: false, lastSave: Date.now() };
	cache.set(key, entry);
	return entry;
}

export function saveReg(dimId, rx, rz, force = false) {
	const key = regKey(dimId, rx, rz);
	const entry = cache.get(key);
	if (!entry) return;
	if (!entry.dirty && !force) return;

	const hex = toHex(entry.bytes);
	world.setDynamicProperty(key, hex);
	entry.dirty = false;
	entry.lastSave = Date.now();
}

export function isChunk(cx, cz, dimId) {
	const { rx, lx: localX } = getRegCoords(cx);
	const { rx: rz, lx: localZ } = getRegCoords(cz);
	const entry = loadReg(dimId, rx, rz);
	const idx = getIdx(localX, localZ);
	const byteIdx = Math.floor(idx / 8);
	const bitIdx = idx % 8;
	return (entry.bytes[byteIdx] & (1 << bitIdx)) !== 0;
}

export function markChunk(cx, cz, dimId) {
	const { rx, lx: localX } = getRegCoords(cx);
	const { rx: rz, lx: localZ } = getRegCoords(cz);
	const entry = loadReg(dimId, rx, rz);
	const idx = getIdx(localX, localZ);
	const byteIdx = Math.floor(idx / 8);
	const bitIdx = idx % 8;
	entry.bytes[byteIdx] |= (1 << bitIdx);
	entry.dirty = true;
}

export function getCache() {
	return cache;
}

export function getPrefix() {
	return PREFIX;
}

export { getRegCoords };
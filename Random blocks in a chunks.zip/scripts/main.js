import { 
    world, 
    system, 
    BlockTypes 
} from "@minecraft/server";
import {
	isChunk,
	markChunk,
	saveReg,
	getRegCoords,
	getCache,
	getPrefix
} from "./database.js";
import {
    BLACKLIST,
    ALLOWED
} from "./list.js";

const AUTHOR = "VigeNerSl";
const FLUSH = 5_000;
const MAX_ITEMS = 100;
const MAX_JOBS = 12;
const OPS = 1000;
const RANGE = 50;
const THRESHOLD = 5;

let blocks = [];
const jobs = new Map();
const targets = new Map();
const lastY = new Map();
const processed = new Map();

system.runTimeout(() => {
	blocks = BlockTypes.getAll();
}, 1);

system.runInterval(() => {
	const cache = getCache();
	const prefix = getPrefix();

	for (const [key, entry] of cache.entries()) {
		if (entry.dirty && Date.now() - entry.lastSave >= FLUSH) {
			const parts = key.replace(prefix, "").split("_");
			const dim = parts[0];
			const rx = parseInt(parts[1]);
			const rz = parseInt(parts[2]);
			saveReg(dim, rx, rz, true);
		}
	}
}, Math.max(1, Math.floor(FLUSH / 50)));

system.runInterval(() => {
	for (const dim of [world.getDimension("overworld"), world.getDimension("nether"), world.getDimension("the_end")]) {
		const items = dim.getEntities({ type: "minecraft:item" });
		
		if (items.length > MAX_ITEMS) {
			for (const item of items) {
				try {
					item.remove();
				} catch (e) {}
			}
		}
	}
}, 20);

function replaceUp(dim, cx, cz, start, target) {
	const minX = cx * 16;
	const minZ = cz * 16;
	const maxX = minX + 15;
	const maxZ = minZ + 15;
	
	const minY = Math.floor(start);
	const maxY = Math.min(dim.heightRange.max - 1, minY + RANGE);

	let ops = 0;

	function* task() {
		for (let y = minY; y <= maxY; y++) {
			for (let x = minX; x <= maxX; x++) {
				for (let z = minZ; z <= maxZ; z++) {
					try {
						const block = dim.getBlock({ x, y, z });
						
						if (!block || block.isAir) continue;
						
						const type = block.typeId;
						if (BLACKLIST.has(type)) continue;
						if (type === target) continue;

						block.setType(target);

						ops++;
						if (ops >= OPS) {
							ops = 0;
							yield;
						}
					} catch (e) {}
				}
			}
		}
	}

	return system.runJob(task());
}

function replaceDown(dim, cx, cz, start, target) {
	const minX = cx * 16;
	const minZ = cz * 16;
	const maxX = minX + 15;
	const maxZ = minZ + 15;
	
	const maxY = Math.floor(start);
	const minY = Math.max(dim.heightRange.min, maxY - RANGE);

	let ops = 0;

	function* task() {
		for (let y = maxY; y >= minY; y--) {
			for (let x = minX; x <= maxX; x++) {
				for (let z = minZ; z <= maxZ; z++) {
					try {
						const block = dim.getBlock({ x, y, z });
						
						if (!block || block.isAir) continue;
						
						const type = block.typeId;
						if (BLACKLIST.has(type)) continue;
						if (type === target) continue;

						block.setType(target);

						ops++;
						if (ops >= OPS) {
							ops = 0;
							yield;
						}
					} catch (e) {}
				}
			}
		}
	}

	return system.runJob(task());
}

function replaceInit(dim, cx, cz, py, target) {
	const minX = cx * 16;
	const minZ = cz * 16;
	const maxX = minX + 15;
	const maxZ = minZ + 15;
	
	const center = Math.floor(py);
	const minY = Math.max(dim.heightRange.min, center - RANGE);
	const maxY = Math.min(dim.heightRange.max - 1, center + RANGE);

	let ops = 0;

	function* task() {
		for (let offset = 0; offset <= RANGE; offset++) {
			if (offset === 0) {
				for (let x = minX; x <= maxX; x++) {
					for (let z = minZ; z <= maxZ; z++) {
						try {
							const block = dim.getBlock({ x, y: center, z });
							
							if (!block || block.isAir) continue;
							
							const type = block.typeId;
							if (BLACKLIST.has(type)) continue;
							if (type === target) continue;

							block.setType(target);

							ops++;
							if (ops >= OPS) {
								ops = 0;
								yield;
							}
						} catch (e) {}
					}
				}
			} else {
				const yUp = center + offset;
				if (yUp <= maxY) {
					for (let x = minX; x <= maxX; x++) {
						for (let z = minZ; z <= maxZ; z++) {
							try {
								const block = dim.getBlock({ x, y: yUp, z });
								
								if (!block || block.isAir) continue;
								
								const type = block.typeId;
								if (BLACKLIST.has(type)) continue;
								if (type === target) continue;

								block.setType(target);

								ops++;
								if (ops >= OPS) {
									ops = 0;
									yield;
								}
							} catch (e) {}
						}
					}
				}
				
				const yDown = center - offset;
				if (yDown >= minY) {
					for (let x = minX; x <= maxX; x++) {
						for (let z = minZ; z <= maxZ; z++) {
							try {
								const block = dim.getBlock({ x, y: yDown, z });
								
								if (!block || block.isAir) continue;
								
								const type = block.typeId;
								if (BLACKLIST.has(type)) continue;
								if (type === target) continue;

								block.setType(target);

								ops++;
								if (ops >= OPS) {
									ops = 0;
									yield;
								}
							} catch (e) {}
						}
					}
				}
			}
		}
	}

	return system.runJob(task());
}

system.runInterval(() => {
	if (blocks.length === 0) return;

	for (const p of world.getAllPlayers()) {
		const loc = p.location;
		const cx = Math.floor(loc.x / 16);
		const cz = Math.floor(loc.z / 16);
		const dim = p.dimension.id;
		const key = `${dim}_${cx}_${cz}`;
		const py = loc.y;

		if (!targets.has(key)) {
			const target = ALLOWED[Math.floor(Math.random() * ALLOWED.length)];
			targets.set(key, target);
		}
		const target = targets.get(key);

		if (!isChunk(cx, cz, dim)) {
			const jKey = `${key}_init`;
			
			if (!jobs.has(jKey)) {
				markChunk(cx, cz, dim);
				const { rx } = getRegCoords(cx);
				const { rx: rz } = getRegCoords(cz);
				saveReg(dim, rx, rz, true);
				
				lastY.set(key, py);
				processed.set(key, { up: py + RANGE, down: py - RANGE });
				
				const jid = replaceInit(p.dimension, cx, cz, py, target);
				jobs.set(jKey, jid);
			}
		} 
		else {
			const ly = lastY.get(key);
			if (ly === undefined) {
				lastY.set(key, py);
				processed.set(key, { up: py + RANGE, down: py - RANGE });
				continue;
			}
			
			const diff = py - ly;
			const proc = processed.get(key) || { up: py, down: py };
			
			if (diff > THRESHOLD && py > proc.up - RANGE) {
				const jKey = `${key}_up`;
				
				if (!jobs.has(jKey) && jobs.size < MAX_JOBS) {
					lastY.set(key, py);
					proc.up = py + RANGE;
					processed.set(key, proc);
					
					const jid = replaceUp(p.dimension, cx, cz, ly + RANGE, target);
					jobs.set(jKey, jid);
				}
			}
			else if (diff < -THRESHOLD && py < proc.down + RANGE) {
				const jKey = `${key}_down`;
				
				if (!jobs.has(jKey) && jobs.size < MAX_JOBS) {
					lastY.set(key, py);
					proc.down = py - RANGE;
					processed.set(key, proc);
					
					const jid = replaceDown(p.dimension, cx, cz, ly - RANGE, target);
					jobs.set(jKey, jid);
				}
			}
		}
	}
}, 1);

system.runInterval(() => {
	const active = new Set();
	
	for (const p of world.getAllPlayers()) {
		const loc = p.location;
		const cx = Math.floor(loc.x / 16);
		const cz = Math.floor(loc.z / 16);
		const dim = p.dimension.id;
		const key = `${dim}_${cx}_${cz}`;
		active.add(key);
		
		for (let dx = -3; dx <= 3; dx++) {
			for (let dz = -3; dz <= 3; dz++) {
				active.add(`${dim}_${cx + dx}_${cz + dz}`);
			}
		}
	}
	
	for (const key of targets.keys()) {
		if (!active.has(key)) {
			targets.delete(key);
			lastY.delete(key);
			processed.delete(key);
		}
	}
	
	for (const jKey of jobs.keys()) {
		const key = jKey.split('_').slice(0, 3).join('_');
		if (!active.has(key)) {
			jobs.delete(jKey);
		}
	}
}, 20 * 30);

function flushAll() {
	const cache = getCache();
	const prefix = getPrefix();

	for (const key of cache.keys()) {
		const parts = key.replace(prefix, "").split("_");
		const dim = parts[0];
		const rx = parseInt(parts[1]);
		const rz = parseInt(parts[2]);
		saveReg(dim, rx, rz, true);
	}
}

system.runInterval(() => {
	flushAll();
}, 60_000 * 5);